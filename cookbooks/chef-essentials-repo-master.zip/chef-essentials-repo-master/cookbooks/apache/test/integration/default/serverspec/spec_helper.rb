require 'serverspec'

set :backend, :exec
