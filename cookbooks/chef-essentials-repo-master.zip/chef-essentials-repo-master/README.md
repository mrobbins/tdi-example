# Chef Essentials Repository - CentOS

This repository contains all the completed cookbooks from the first day (Modules 02-07) of the [Chef Essentials Windows](https://github.com/chef-training/chef-essentials) content.

* The apache cookbook is able to deploy apache on an CentOS 6.7 instance.

* The workstation cookbook is able to deploy necessary tools on an CentOS 6.7 instance.
